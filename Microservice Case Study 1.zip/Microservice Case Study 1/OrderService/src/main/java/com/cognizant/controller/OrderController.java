package com.cognizant.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Cash;
import com.cognizant.service.OrderItemService;
import com.cognizant.service.OrderService;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private OrderItemService orderItemService;
	
	@PostMapping("/placeOrder")
	public ResponseEntity<Object> placeorder(@RequestBody Cash order){
		if(orderService.addOrder(order)&&orderItemService.addOrderItems(order)) {
		return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else 
			return new ResponseEntity<Object>("Cannot add",HttpStatus.BAD_REQUEST);
	}
	
}
