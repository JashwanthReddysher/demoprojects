package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Cash;
import com.cognizant.model.OrderItem;
import com.cognizant.repository.OrderItemRepository;

@Service
@Transactional
public class OrderItemService {
	
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private OrderItemRepository orderItemRepository;
	

	public boolean addItem(OrderItem orderItem) {
		OrderItem o=orderItemRepository.save(orderItem);
		if(o!=null) {
			return true;
		}
		return false;
	}

	public boolean addOrderItems(Cash order) {
		List<Cash> list=orderService.getOrderItems();
		int n=list.size()-1;
		int id=list.get(n).getOrderId();
		
		List<OrderItem> items=order.getOrderItems();
		for(OrderItem o:items) {
			o.setOrderId(id);;
			if(!addItem(o)) {return false;}
		}
		return true;
		}

}
