package com.cts.authenticationservice;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapSeed implements CommandLineRunner {
    private UserRepository repository;

    public BootStrapSeed(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        ApplicationUser user1=new ApplicationUser();
        user1.setUserName("shubham");
        user1.setPassword("shubham");
        repository.save(user1);

    }
}

