package com.example.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.model.Admin;
import com.example.service.UserService;

@Controller
public class UserController {
	
	private UserService userService;
	
	/* SuperAdmin-Approve */
	@SuppressWarnings("unused")
	@RequestMapping(value = "/updateStatus/{id}")
	public String updateStatus(@RequestParam(value="status",required=false) String status, @PathVariable("id") Long id,
			ModelMap model) {

		
		boolean result = userService.updateStatus(id, status);
		List<Admin> m = userService.AdminId();
		
		model.addAttribute("list", m);
		
		return "superadmin-approve-admin";
	}
	
	
	@PostMapping("/registerAdmin")
	public String saveUser(@ModelAttribute("admin") Admin admin, Model model, @RequestParam("file") MultipartFile file) {
		
	
		
		try {

			byte[] image = file.getBytes();

			admin.setPicture(image);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		if (admin.getRole().equals("Admin"))
			admin.setStatus("pending");
		else
			admin.setStatus("approved");
		String result = userService.register(admin);

		if (result.equals("exists"))
			model.addAttribute("msg", "User Id already exists");
		else if (result.equals("success"))
			model.addAttribute("msg", "Details saved successfully");
		model.addAttribute("adminLogin", new Admin());
		return "somesuccess";

	}
}
