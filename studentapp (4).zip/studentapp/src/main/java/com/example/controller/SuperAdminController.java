package com.example.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Admin;
import com.example.model.SuperAdmin;
import com.example.service.SuperAdminService;

@Controller
public class SuperAdminController {
	
	@Autowired
	private SuperAdminService superAdminService;
	
	@GetMapping("/superAdminLogin")
	public ModelAndView superAdminLogin() {
		ModelAndView mav=new ModelAndView("SuperAdminLogin");
		mav.addObject("superAdmin", new SuperAdmin());
		return mav;
	}
	
	@PostMapping("/superAdmin1")
	public String login(@ModelAttribute("superAdmin") SuperAdmin superAdmin) {
		SuperAdmin authSuperAdmin = superAdminService.login(superAdmin.getSuperAdminId(),superAdmin.getPassword());
		System.out.println(authSuperAdmin);
		if(Objects.nonNull(authSuperAdmin)) {
			return"redirect:/alladmins";
		}
		else {
			return "adminError";
		}
	}
	

}
