package com.example.service;

import java.util.List;

import javax.validation.Valid;

import com.example.model.Admin;

public interface UserService {
	
	
	
	List<Admin> AdminId();

	boolean updateStatus(Long id, String status);

	String register(@Valid Admin admin);


}
