package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Admin;
import com.example.model.Students;
import com.example.repository.AdminRepository;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;

//	public void register(Admin admin) {
//		adminRepository.save(admin);
//		
//	}
	public Admin login(String adminId, String password) {
		
		Admin admin= adminRepository.findByAdminIdAndPassword(adminId,password);
	
		return admin;
	}
	
	public List<Admin> listAll(){
		return adminRepository.findAll();		
	}
	public Admin get(int id) {
		return adminRepository.findById((long) id).get();
	}
	public void delete(int id) {
		adminRepository.deleteById((long) id);
	}
}