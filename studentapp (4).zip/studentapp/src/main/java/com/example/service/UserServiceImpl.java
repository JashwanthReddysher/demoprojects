package com.example.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Admin;
import com.example.repository.AdminRepository;
import com.example.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userDao;
	
	@Autowired
	private AdminRepository adminRepository;
	
	private ModelMapper modelMapper;
	
	@Override
	public List<Admin> AdminId() {
		// TODO Auto-generated method stub
		List<Admin> adminList = userDao.id();

		List<Admin> empDto = new ArrayList<>();

		for (Admin e : adminList)

		{
			Admin edto = modelMapper.map(e, Admin.class);

			empDto.add(edto);

		}
		System.out.println("service list size=" + empDto.size());

		return empDto;
	}

	@Transactional
	@Override
	public boolean updateStatus(Long id, String status) {
		// TODO Auto-generated method stub
		boolean result = false;
		int res = userDao.updateStatus(id, status);
		System.out.println("rows updated=" + res);
		if (res > 0)
			result = true;
		return result;
	}
	
	
	@Override
	public String register(Admin admin) {
		// TODO Auto-generated method stub
		String result = "success";
		System.out.println(admin.getStatus());

		Admin u = modelMapper.map(admin, Admin.class);

		boolean found = userDao.existsById(admin.getId());

		System.out.println("found=" + found);

		if (found)

		{
			result = "exists";

		}

		else {

			Admin res = adminRepository.save(u);

			if (res == null)

				result = "failure";

		}
		return result;
}




}
