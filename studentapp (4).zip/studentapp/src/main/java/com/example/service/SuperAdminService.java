package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Admin;
import com.example.model.SuperAdmin;
import com.example.repository.SuperAdminRepository;

@Service

public class SuperAdminService {

	@Autowired
	SuperAdminRepository superAdminRepository;
	
	public void register(SuperAdmin superAdmin) {
		superAdminRepository.save(superAdmin);
		
	}
	public SuperAdmin login(String superAdminId, String password) {
		
		SuperAdmin superAdmin= superAdminRepository.findBySuperAdminIdAndPassword(superAdminId,password);
	
		return superAdmin;
	}
	
}
