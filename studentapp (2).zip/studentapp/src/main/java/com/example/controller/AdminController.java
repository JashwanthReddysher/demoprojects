package com.example.controller;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.model.Admin;
import com.example.service.AdminService;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/login")
	public ModelAndView Login() {
		ModelAndView mav=new ModelAndView("login");
		mav.addObject("admin", new Admin());
		return mav;
	}
	
	@PostMapping("/login")
	public String login(@ModelAttribute("admin") Admin admin) {
		Admin authAdmin = adminService.login(admin.getAdminId(),admin.getPassword());
		System.out.println(authAdmin);
		if(Objects.nonNull(authAdmin)) {
			return "redirect:/admin";
		}
		else {
			return "redirect:/adminLogin";
		}
	}
	
//	@RequestMapping ("/login-admin")
//	public String loginUser(@ModelAttribute Admin admin, HttpServletRequest request) {
//		if(adminService.findByUsernameAndPassword(admin.getAdminId(), admin.getPassword())!=null) {
//			return "student";
//		}
//		else {
//			request.setAttribute("error", "Invalid Name or Password");
//			request.setAttribute("mode", "MODE_LOGIN");
//			return "student";
//			
//		}
	}
	


