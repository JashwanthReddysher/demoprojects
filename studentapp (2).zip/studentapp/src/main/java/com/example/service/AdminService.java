package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.model.Admin;
import com.example.repository.AdminRepository;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;

	public Admin login(String adminId, String password) {
		
		Admin admin= adminRepository.findByNameAndPassword(adminId, password);
		return admin;
	}
	

}